﻿

namespace _3C1NIKOLAS31.Code.DTO
{
    internal class SGamesDTO
    {
        private string _id;
        private string _produto;
        private string _preco;

        public string Id { get => _id; set => _id = value; }
        public string Produto { get => _produto; set => _produto = value; }
        public string Preco { get => _preco; set => _preco = value; }
    }
}
